// bptree.hpp - Generic B+ tree (in-memory) with leaf linked list.
//
//  * All records live in the leaves; internal nodes only hold routing keys.
//  * Leaves are chained (next pointer) so range queries are a simple walk.
//  * 'order' = maximum number of children of an internal node.
//      max keys per node        = order - 1
//      min keys per leaf        = order / 2
//      min keys per internal    = ceil(order / 2) - 1   (root is exempt)
//
// Complexity (n = records, m = order):  search / insert / delete = O(log_m n)
//                                       range query            = O(log_m n + k)
#pragma once
#include <algorithm>
#include <cstddef>
#include <functional>
#include <sstream>
#include <string>
#include <vector>

template <typename K, typename V>
class BPlusTree {
public:
    struct Node {
        bool leaf;
        std::vector<K> keys;
        std::vector<Node*> children;  // internal nodes only
        std::vector<V> values;        // leaf nodes only
        Node* next = nullptr;         // leaf chain
        explicit Node(bool l) : leaf(l) {}
    };

    // Flat description of one node, used for printing / drawing the tree.
    struct NodeInfo {
        int level;                 // 0 = root
        bool leaf;
        std::vector<K> keys;
        std::vector<int> children; // indices into the snapshot vector
    };

    explicit BPlusTree(int order = 4) : order_(order < 3 ? 3 : order) { root_ = new Node(true); }
    ~BPlusTree() { destroy(root_); }
    BPlusTree(const BPlusTree&) = delete;
    BPlusTree& operator=(const BPlusTree&) = delete;

    int order() const { return order_; }
    std::size_t size() const { return size_; }
    bool empty() const { return size_ == 0; }
    std::size_t lastVisits() const { return visits_; }  // nodes touched by last search

    void clear() {
        destroy(root_);
        root_ = new Node(true);
        size_ = 0;
    }

    // ---------------------------------------------------------------- INSERT
    // Returns false if the key already exists (keys are unique).
    bool insert(const K& key, const V& value) {
        K up{};
        Node* newChild = nullptr;
        if (!insertRec(root_, key, value, up, newChild)) return false;
        if (newChild) {  // root was split -> tree grows one level
            Node* r = new Node(false);
            r->keys.push_back(up);
            r->children.push_back(root_);
            r->children.push_back(newChild);
            root_ = r;
        }
        ++size_;
        return true;
    }

    // ---------------------------------------------------------------- SEARCH
    V* find(const K& key) {
        Node* leaf = findLeaf(key);
        auto it = std::lower_bound(leaf->keys.begin(), leaf->keys.end(), key);
        if (it == leaf->keys.end() || key < *it) return nullptr;
        return &leaf->values[it - leaf->keys.begin()];
    }
    bool contains(const K& key) { return find(key) != nullptr; }

    // ---------------------------------------------------------------- UPDATE
    bool update(const K& key, const V& value) {
        V* v = find(key);
        if (!v) return false;
        *v = value;
        return true;
    }

    // ---------------------------------------------------------------- DELETE
    bool remove(const K& key) {
        if (!removeRec(root_, key)) return false;
        --size_;
        if (!root_->leaf && root_->keys.empty()) {  // root shrank -> tree loses a level
            Node* old = root_;
            root_ = root_->children[0];
            old->children.clear();
            delete old;
        }
        return true;
    }

    // ----------------------------------------------------------------- RANGE
    // Calls fn(key, value) for every lo <= key <= hi in sorted order.
    void range(const K& lo, const K& hi, const std::function<void(const K&, V&)>& fn) {
        Node* leaf = findLeaf(lo);
        while (leaf) {
            for (std::size_t i = 0; i < leaf->keys.size(); ++i) {
                if (leaf->keys[i] < lo) continue;
                if (hi < leaf->keys[i]) return;
                fn(leaf->keys[i], leaf->values[i]);
            }
            leaf = leaf->next;
        }
    }

    // In-order traversal of everything (walks the leaf chain).
    void forEach(const std::function<void(const K&, V&)>& fn) {
        Node* leaf = leftmostLeaf();
        while (leaf) {
            for (std::size_t i = 0; i < leaf->keys.size(); ++i) fn(leaf->keys[i], leaf->values[i]);
            leaf = leaf->next;
        }
    }

    // ----------------------------------------------------------- INTROSPECTION
    int height() const {
        int h = 1;
        for (Node* n = root_; !n->leaf; n = n->children[0]) ++h;
        return h;
    }

    std::size_t nodeCount() const { return snapshot().size(); }

    std::vector<NodeInfo> snapshot() const {
        std::vector<NodeInfo> out;
        std::vector<std::pair<Node*, int>> queue;  // node, level
        queue.push_back({root_, 0});
        std::vector<int> parentOf;
        for (std::size_t head = 0; head < queue.size(); ++head) {
            Node* n = queue[head].first;
            NodeInfo info;
            info.level = queue[head].second;
            info.leaf = n->leaf;
            info.keys = n->keys;
            if (!n->leaf) {
                for (Node* c : n->children) {
                    info.children.push_back(static_cast<int>(queue.size()));
                    queue.push_back({c, info.level + 1});
                }
            }
            out.push_back(info);
        }
        return out;
    }

    // Text drawing: one line per level, nodes as [k1|k2|k3].
    std::string toString() const {
        auto snap = snapshot();
        std::ostringstream os;
        int curLevel = -1;
        for (const auto& n : snap) {
            if (n.level != curLevel) {
                if (curLevel != -1) os << '\n';
                curLevel = n.level;
                os << (n.level == 0 ? "root  " : "L" + std::to_string(n.level) + "    ");
            }
            os << '[';
            for (std::size_t i = 0; i < n.keys.size(); ++i) os << (i ? "|" : "") << n.keys[i];
            os << "] ";
        }
        os << '\n';
        return os.str();
    }

    // Verifies every B+ tree invariant. Returns true if the tree is valid.
    bool validate(std::string* err = nullptr) const {
        int leafDepth = -1;
        std::string msg;
        bool ok = check(root_, true, 0, leafDepth, nullptr, nullptr, msg);
        if (ok) {  // leaf chain must be strictly increasing and cover size_ keys
            std::size_t count = 0;
            const K* prev = nullptr;
            for (Node* l = leftmostLeaf(); l; l = l->next)
                for (const K& k : l->keys) {
                    if (prev && !(*prev < k)) { ok = false; msg = "leaf chain not sorted"; }
                    prev = &k;
                    ++count;
                }
            if (ok && count != size_) { ok = false; msg = "size mismatch"; }
        }
        if (!ok && err) *err = msg;
        return ok;
    }

private:
    int order_;
    Node* root_;
    std::size_t size_ = 0;
    mutable std::size_t visits_ = 0;

    std::size_t maxKeys() const { return static_cast<std::size_t>(order_ - 1); }
    std::size_t minLeaf() const { return static_cast<std::size_t>(order_ / 2); }
    std::size_t minInternal() const { return static_cast<std::size_t>((order_ + 1) / 2 - 1); }
    std::size_t minKeys(const Node* n) const { return n->leaf ? minLeaf() : minInternal(); }

    static void destroy(Node* n) {
        if (!n) return;
        for (Node* c : n->children) destroy(c);
        delete n;
    }

    Node* leftmostLeaf() const {
        Node* n = root_;
        while (!n->leaf) n = n->children[0];
        return n;
    }

    // index of the child to follow for 'key'
    static std::size_t childIndex(const Node* n, const K& key) {
        return std::upper_bound(n->keys.begin(), n->keys.end(), key) - n->keys.begin();
    }

    Node* findLeaf(const K& key) const {
        visits_ = 1;
        Node* n = root_;
        while (!n->leaf) {
            n = n->children[childIndex(n, key)];
            ++visits_;
        }
        return n;
    }

    // ---- insert helpers
    bool insertRec(Node* n, const K& key, const V& value, K& up, Node*& newChild) {
        newChild = nullptr;
        if (n->leaf) {
            auto it = std::lower_bound(n->keys.begin(), n->keys.end(), key);
            if (it != n->keys.end() && !(key < *it)) return false;  // duplicate
            std::size_t pos = it - n->keys.begin();
            n->keys.insert(it, key);
            n->values.insert(n->values.begin() + pos, value);
            if (n->keys.size() > maxKeys()) splitLeaf(n, up, newChild);
            return true;
        }
        std::size_t idx = childIndex(n, key);
        K childUp{};
        Node* childNew = nullptr;
        if (!insertRec(n->children[idx], key, value, childUp, childNew)) return false;
        if (childNew) {
            n->keys.insert(n->keys.begin() + idx, childUp);
            n->children.insert(n->children.begin() + idx + 1, childNew);
            if (n->keys.size() > maxKeys()) splitInternal(n, up, newChild);
        }
        return true;
    }

    // Leaf split: the first key of the new right leaf is COPIED up to the parent.
    void splitLeaf(Node* n, K& up, Node*& newChild) {
        std::size_t leftCount = (n->keys.size() + 1) / 2;
        Node* r = new Node(true);
        r->keys.assign(n->keys.begin() + leftCount, n->keys.end());
        r->values.assign(n->values.begin() + leftCount, n->values.end());
        n->keys.erase(n->keys.begin() + leftCount, n->keys.end());
        n->values.erase(n->values.begin() + leftCount, n->values.end());
        r->next = n->next;
        n->next = r;
        up = r->keys.front();
        newChild = r;
    }

    // Internal split: the middle key is MOVED up to the parent.
    void splitInternal(Node* n, K& up, Node*& newChild) {
        std::size_t mid = n->keys.size() / 2;
        Node* r = new Node(false);
        up = n->keys[mid];
        r->keys.assign(n->keys.begin() + mid + 1, n->keys.end());
        r->children.assign(n->children.begin() + mid + 1, n->children.end());
        n->keys.erase(n->keys.begin() + mid, n->keys.end());
        n->children.erase(n->children.begin() + mid + 1, n->children.end());
        newChild = r;
    }

    // ---- delete helpers
    bool removeRec(Node* n, const K& key) {
        if (n->leaf) {
            auto it = std::lower_bound(n->keys.begin(), n->keys.end(), key);
            if (it == n->keys.end() || key < *it) return false;
            std::size_t pos = it - n->keys.begin();
            n->keys.erase(it);
            n->values.erase(n->values.begin() + pos);
            return true;
        }
        std::size_t idx = childIndex(n, key);
        Node* child = n->children[idx];
        if (!removeRec(child, key)) return false;
        if (child->keys.size() < minKeys(child)) fixUnderflow(n, idx);
        return true;
    }

    // Child 'i' of 'p' has too few keys: borrow from a sibling, else merge.
    void fixUnderflow(Node* p, std::size_t i) {
        Node* c = p->children[i];
        Node* left = i > 0 ? p->children[i - 1] : nullptr;
        Node* right = i + 1 < p->children.size() ? p->children[i + 1] : nullptr;

        if (left && left->keys.size() > minKeys(left)) {
            if (c->leaf) {
                c->keys.insert(c->keys.begin(), left->keys.back());
                c->values.insert(c->values.begin(), left->values.back());
                left->keys.pop_back();
                left->values.pop_back();
                p->keys[i - 1] = c->keys.front();
            } else {
                c->keys.insert(c->keys.begin(), p->keys[i - 1]);
                c->children.insert(c->children.begin(), left->children.back());
                p->keys[i - 1] = left->keys.back();
                left->keys.pop_back();
                left->children.pop_back();
            }
        } else if (right && right->keys.size() > minKeys(right)) {
            if (c->leaf) {
                c->keys.push_back(right->keys.front());
                c->values.push_back(right->values.front());
                right->keys.erase(right->keys.begin());
                right->values.erase(right->values.begin());
                p->keys[i] = right->keys.front();
            } else {
                c->keys.push_back(p->keys[i]);
                c->children.push_back(right->children.front());
                p->keys[i] = right->keys.front();
                right->keys.erase(right->keys.begin());
                right->children.erase(right->children.begin());
            }
        } else if (left) {
            mergeChildren(p, i - 1);
        } else {
            mergeChildren(p, i);
        }
    }

    // Merge child idx+1 into child idx and drop the separator key.
    void mergeChildren(Node* p, std::size_t idx) {
        Node* l = p->children[idx];
        Node* r = p->children[idx + 1];
        if (l->leaf) {
            l->keys.insert(l->keys.end(), r->keys.begin(), r->keys.end());
            l->values.insert(l->values.end(), r->values.begin(), r->values.end());
            l->next = r->next;
        } else {
            l->keys.push_back(p->keys[idx]);
            l->keys.insert(l->keys.end(), r->keys.begin(), r->keys.end());
            l->children.insert(l->children.end(), r->children.begin(), r->children.end());
            r->children.clear();
        }
        p->keys.erase(p->keys.begin() + idx);
        p->children.erase(p->children.begin() + idx + 1);
        delete r;
    }

    // ---- invariant checker
    bool check(const Node* n, bool isRoot, int depth, int& leafDepth, const K* lo, const K* hi,
               std::string& err) const {
        if (n->keys.size() > maxKeys()) { err = "node overflow"; return false; }
        if (!isRoot && n->keys.size() < minKeys(n)) { err = "node underflow"; return false; }
        for (std::size_t i = 0; i < n->keys.size(); ++i) {
            if (i && !(n->keys[i - 1] < n->keys[i])) { err = "keys not sorted"; return false; }
            if (lo && n->keys[i] < *lo) { err = "key below lower bound"; return false; }
            if (hi && !(n->keys[i] < *hi)) { err = "key above upper bound"; return false; }
        }
        if (n->leaf) {
            if (n->values.size() != n->keys.size()) { err = "leaf key/value mismatch"; return false; }
            if (leafDepth == -1) leafDepth = depth;
            else if (leafDepth != depth) { err = "leaves at different depths"; return false; }
            return true;
        }
        if (n->children.size() != n->keys.size() + 1) { err = "child count mismatch"; return false; }
        if (isRoot && n->keys.empty()) { err = "empty internal root"; return false; }
        for (std::size_t i = 0; i < n->children.size(); ++i) {
            const K* clo = i == 0 ? lo : &n->keys[i - 1];
            const K* chi = i == n->keys.size() ? hi : &n->keys[i];
            if (!check(n->children[i], false, depth + 1, leafDepth, clo, chi, err)) return false;
        }
        return true;
    }
};
