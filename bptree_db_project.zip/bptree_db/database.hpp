// database.hpp - A tiny "Student" table whose primary-key index is a B+ tree.
#pragma once
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>

#include "bptree.hpp"

struct Student {
    int id = 0;            // primary key
    std::string name;
    std::string dept;
    double cgpa = 0.0;
};

class StudentDB {
public:
    explicit StudentDB(int order = 4) : tree_(new Index(order)) {}
    ~StudentDB() { delete tree_; }
    StudentDB(const StudentDB&) = delete;
    StudentDB& operator=(const StudentDB&) = delete;

    using Index = BPlusTree<int, Student>;
    Index& index() { return *tree_; }
    const Index& index() const { return *tree_; }

    // ---- CRUD ---------------------------------------------------------
    bool insert(Student s) { clean(s); return tree_->insert(s.id, s); }
    const Student* get(int id) { return tree_->find(id); }
    bool update(Student s) { clean(s); return tree_->update(s.id, s); }
    bool remove(int id) { return tree_->remove(id); }
    std::size_t count() const { return tree_->size(); }

    // ---- queries ------------------------------------------------------
    std::vector<Student> range(int lo, int hi) {
        std::vector<Student> out;
        tree_->range(lo, hi, [&](const int&, Student& s) { out.push_back(s); });
        return out;
    }
    std::vector<Student> all() { return range(INT32_MIN, INT32_MAX); }

    // Non-key search: needs a full scan of the leaf chain, O(n).
    std::vector<Student> searchName(const std::string& part) {
        std::vector<Student> out;
        std::string p = lower(part);
        tree_->forEach([&](const int&, Student& s) {
            if (lower(s.name).find(p) != std::string::npos) out.push_back(s);
        });
        return out;
    }

    // ---- maintenance --------------------------------------------------
    // Rebuild the index with a different order (re-inserts all rows).
    void setOrder(int order) {
        std::vector<Student> rows = all();
        delete tree_;
        tree_ = new Index(order);
        for (auto& s : rows) tree_->insert(s.id, s);
    }

    void clear() { tree_->clear(); }

    // ---- persistence (CSV: id,name,dept,cgpa) ---------------------------
    bool save(const std::string& path) {
        std::ofstream f(path);
        if (!f) return false;
        f << "id,name,dept,cgpa\n";
        tree_->forEach([&](const int&, Student& s) {
            f << s.id << ',' << s.name << ',' << s.dept << ',' << s.cgpa << '\n';
        });
        return true;
    }

    // Returns number of rows loaded, or -1 if file cannot be opened.
    int load(const std::string& path) {
        std::ifstream f(path);
        if (!f) return -1;
        std::string line;
        std::getline(f, line);  // header
        int n = 0;
        while (std::getline(f, line)) {
            std::stringstream ss(line);
            std::string id, name, dept, cgpa;
            if (!std::getline(ss, id, ',') || !std::getline(ss, name, ',') ||
                !std::getline(ss, dept, ',') || !std::getline(ss, cgpa, ','))
                continue;
            try {
                Student s{std::stoi(id), name, dept, std::stod(cgpa)};
                if (insert(s)) ++n;
            } catch (...) { /* skip malformed row */ }
        }
        return n;
    }

    static std::string format(const Student& s) {
        std::ostringstream os;
        os << std::setw(8) << s.id << "  " << std::left << std::setw(18) << s.name << std::setw(8)
           << s.dept << std::right << std::fixed << std::setprecision(2) << s.cgpa;
        return os.str();
    }

private:
    Index* tree_;

    static void clean(Student& s) {  // keep the CSV format safe
        for (char& c : s.name) if (c == ',' || c == '\n') c = ' ';
        for (char& c : s.dept) if (c == ',' || c == '\n') c = ' ';
    }
    static std::string lower(std::string s) {
        for (char& c : s) c = static_cast<char>(tolower(static_cast<unsigned char>(c)));
        return s;
    }
};
