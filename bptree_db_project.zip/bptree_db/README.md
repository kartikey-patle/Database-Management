# Database Operations Using B+ Trees
Fundamentals of Data Structures - Course Project (C++17, GTK3 GUI)

## 1. What this project is
A small in-memory database for a `Student(id, name, dept, cgpa)` table. The primary-key
index is a **B+ tree written from scratch** (no STL containers for the tree logic, only
`std::vector` inside nodes). All database operations go through the tree.

| Operation        | How it uses the B+ tree                                   | Cost            |
|------------------|-----------------------------------------------------------|-----------------|
| INSERT           | descend to leaf, insert in sorted position, split if full | O(log n)        |
| SELECT by id     | descend root -> leaf, binary search in leaf               | O(log n)        |
| UPDATE           | find the record, overwrite value                          | O(log n)        |
| DELETE           | remove from leaf, borrow from sibling or merge            | O(log n)        |
| RANGE (a..b)     | find leaf of `a`, walk the leaf linked list until `b`     | O(log n + k)    |
| SELECT by name   | full walk of leaf chain (no index on name)                | O(n)            |
| Save / Load CSV  | leaf-chain traversal / repeated insert                    | O(n) / O(n log n) |

## 2. Files
- `bptree.hpp`   - generic `BPlusTree<K,V>`: insert, find, update, remove, range, forEach, validate, snapshot
- `database.hpp` - `StudentDB`: CRUD + queries + CSV persistence on top of the tree
- `main_cli.cpp` - interactive shell (`help` lists commands) incl. `tree`, `stats`, `bench`
- `main_gui.cpp` - GTK3 GUI: forms, results table, live drawing of the tree
- `test_bptree.cpp` - randomized test vs `std::map` (240,000 operations, orders 3-16, invariant checks)
- `sample_students.csv` - demo data

## 3. Build and run
```
sudo apt install build-essential libgtk-3-dev pkg-config   # GUI only needs the gtk part
make test      # builds and runs the correctness tests
make cli       # ./bptree_cli
make gui       # ./bptree_gui
```

## 4. B+ tree design
- `order m` = max children per internal node. Max keys = m-1.
- Min keys: leaf = floor(m/2), internal = ceil(m/2)-1 (root exempt).
- Data only in leaves; internal nodes hold copies of keys for routing.
- Leaves are linked left to right -> fast range queries and ordered scans.
- Keys are unique (duplicate insert is rejected).

**Insert.** Insert into leaf. If keys > m-1: split. Leaf split *copies* the first key of the
right half up; internal split *moves* the middle key up. If the root splits, the tree grows
one level (this is the only way the height increases).

**Delete.** Remove from leaf. If the node has fewer than the minimum keys: (1) borrow from
left sibling, else (2) borrow from right sibling, else (3) merge with a sibling and delete
the separator from the parent (which may underflow in turn). If the root is left with no
keys, its only child becomes the root (the only way the height decreases).

**Why B+ tree for databases?** Very high fan-out -> tiny height (100,000 records with order 64
= height 3). Each node = one disk page, so lookups cost ~3 page reads. Leaf chain gives cheap
range scans. Compared with a B tree, internal nodes are smaller (no data), so more keys fit
per page.

## 5. Results from our benchmark (`bench 100000`, order 64)
- Tree height 3, **about 3 nodes visited per lookup**
- 2000 lookups: ~0.5 ms with B+ tree vs ~260 ms by linear scan (~500x faster)

## 6. Demo script for the review (CLI)
```
load sample_students.csv
tree
get 104
range 103 107
find a
insert 111 Neel IT 8.0
delete 101
order 3
tree
stats          <- shows "valid yes" (all invariants hold)
bench 100000
```
For the GUI: press *Generate* (20 rows), then watch the tree drawing change on every
Insert/Delete; change *Tree order* to show a different shape for the same data.

## 7. Likely viva questions
1. *Difference between B tree and B+ tree?* B+ keeps all data in leaves, leaves are linked, keys repeat in internal nodes.
2. *Why is the height O(log_m n)?* Every node (except root) has at least ceil(m/2) children.
3. *When does the height grow/shrink?* Only on root split / root becoming empty.
4. *Why copy the key up on leaf split but move it up on internal split?* The leaf must still hold the key (data lives there); internal keys are only separators.
5. *What happens on delete if sibling has spare keys?* Borrow and fix the parent separator.
6. *Why is name search O(n)?* The index is on id; a second B+ tree on name would be needed.
7. *Time complexity of range query?* O(log n + k), k = rows returned.
8. *How did you test it?* Randomized comparison against `std::map` plus a `validate()` checker for sortedness, fill factor, equal leaf depth, and leaf-chain order.
9. *Limitations / future work?* In-memory only (could store nodes as disk pages), unique keys only, no transactions/concurrency, single index.
