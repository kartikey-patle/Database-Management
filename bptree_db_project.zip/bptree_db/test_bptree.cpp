// test_bptree.cpp - randomized test against std::map for several orders.
#include <cassert>
#include <iostream>
#include <map>
#include <random>
#include "bptree.hpp"

int main() {
    std::mt19937 rng(12345);
    long ops = 0;
    for (int order : {3, 4, 5, 6, 7, 16}) {
        BPlusTree<int, int> t(order);
        std::map<int, int> ref;
        for (int step = 0; step < 40000; ++step) {
            int k = rng() % 2000, op = rng() % 10;
            if (op < 5) {  // insert
                bool a = t.insert(k, k * 2), b = ref.emplace(k, k * 2).second;
                assert(a == b);
            } else if (op < 8) {  // delete
                bool a = t.remove(k), b = ref.erase(k) > 0;
                assert(a == b);
            } else if (op == 8) {  // search
                int* p = t.find(k);
                assert((p != nullptr) == (ref.count(k) > 0));
                if (p) assert(*p == k * 2);
            } else {  // range
                int lo = k, hi = k + rng() % 200;
                std::vector<int> got, want;
                t.range(lo, hi, [&](const int& key, int&) { got.push_back(key); });
                for (auto it = ref.lower_bound(lo); it != ref.end() && it->first <= hi; ++it) want.push_back(it->first);
                assert(got == want);
            }
            ++ops;
            if (step % 500 == 0) { std::string e; if (!t.validate(&e)) { std::cout << "INVALID order " << order << ": " << e << "\n"; return 1; } }
            assert(t.size() == ref.size());
        }
        // delete everything -> must end as a single empty leaf
        for (auto& kv : std::map<int,int>(ref)) { assert(t.remove(kv.first)); }
        std::string e;
        assert(t.validate(&e) && t.size() == 0 && t.height() == 1);
        std::cout << "order " << order << ": OK\n";
    }
    std::cout << "ALL TESTS PASSED (" << ops << " random operations)\n";
}
