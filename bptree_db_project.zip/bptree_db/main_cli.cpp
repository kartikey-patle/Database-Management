// main_cli.cpp - Command-line shell for the B+ tree database.
#include <chrono>
#include <iostream>
#include <random>
#include <sstream>

#include "database.hpp"

static void help() {
    std::cout <<
        "Commands:\n"
        "  insert <id> <name> <dept> <cgpa>   add a record (name without spaces)\n"
        "  get <id>                           point search by primary key\n"
        "  update <id> <name> <dept> <cgpa>   modify a record\n"
        "  delete <id>                        remove a record\n"
        "  range <lo> <hi>                    all records with lo <= id <= hi\n"
        "  find <text>                        search by name (full scan)\n"
        "  list                               all records in key order\n"
        "  tree                               print the B+ tree structure\n"
        "  stats                              order, height, nodes, records\n"
        "  order <m>                          rebuild index with new order (>=3)\n"
        "  gen <n>                            insert n random records\n"
        "  bench <n>                          B+ tree vs linear scan benchmark\n"
        "  save <file> | load <file>          CSV persistence\n"
        "  clear | help | exit\n";
}

static void print(const std::vector<Student>& v) {
    std::cout << "      ID  NAME              DEPT    CGPA\n";
    for (auto& s : v) std::cout << StudentDB::format(s) << '\n';
    std::cout << "(" << v.size() << " row" << (v.size() == 1 ? "" : "s") << ")\n";
}

static void generate(StudentDB& db, int n, std::mt19937& rng) {
    static const char* names[] = {"Aarav", "Diya", "Rohan", "Isha", "Kabir", "Meera", "Vivaan",
                                  "Anaya", "Arjun", "Sara", "Neel", "Tara", "Yash", "Riya"};
    static const char* depts[] = {"CSE", "ECE", "MECH", "CIVIL", "IT", "EEE"};
    int added = 0;
    while (added < n) {
        Student s;
        s.id = 1000 + static_cast<int>(rng() % 1000000);
        s.name = names[rng() % 14];
        s.dept = depts[rng() % 6];
        s.cgpa = 5.0 + (rng() % 501) / 100.0;
        if (db.insert(s)) ++added;
    }
}

static void bench(int n) {
    using clk = std::chrono::steady_clock;
    std::mt19937 rng(42);
    std::vector<int> ids(n);
    for (int i = 0; i < n; ++i) ids[i] = i + 1;
    std::shuffle(ids.begin(), ids.end(), rng);

    StudentDB db(64);
    std::vector<Student> flat;  // unsorted array = "no index"
    auto t0 = clk::now();
    for (int id : ids) { Student s{id, "x", "CSE", 8.0}; db.insert(s); flat.push_back(s); }
    auto t1 = clk::now();

    const int Q = 2000;
    std::size_t visits = 0, hit = 0;
    for (int q = 0; q < Q; ++q) {
        int key = 1 + rng() % n;
        if (db.get(key)) ++hit;
        visits += db.index().lastVisits();
    }
    auto t2 = clk::now();
    std::size_t hit2 = 0;
    for (int q = 0; q < Q; ++q) {
        int key = 1 + rng() % n;
        for (auto& s : flat) if (s.id == key) { ++hit2; break; }
    }
    auto t3 = clk::now();
    auto ms = [](clk::time_point a, clk::time_point b) {
        return std::chrono::duration<double, std::milli>(b - a).count();
    };
    std::cout << "n = " << n << " records, order 64, height " << db.index().height() << "\n"
              << "build (insert " << n << ")   : " << ms(t0, t1) << " ms\n"
              << Q << " B+ tree lookups : " << ms(t1, t2) << " ms  (avg " << double(visits) / Q
              << " nodes visited per lookup)\n"
              << Q << " linear lookups  : " << ms(t2, t3) << " ms  (avg ~" << n / 2
              << " comparisons per lookup)\n"
              << "hits " << hit << "/" << hit2 << "\n";
}

int main() {
    StudentDB db(4);
    std::mt19937 rng(std::random_device{}());
    std::cout << "B+ Tree Database (order 4). Type 'help'.\n";
    std::string line;
    while (std::cout << "bptree> " && std::getline(std::cin, line)) {
        std::istringstream in(line);
        std::string cmd;
        in >> cmd;
        if (cmd.empty()) continue;
        if (cmd == "exit" || cmd == "quit") break;
        else if (cmd == "help") help();
        else if (cmd == "insert" || cmd == "update") {
            Student s;
            if (!(in >> s.id >> s.name >> s.dept >> s.cgpa)) { std::cout << "usage: " << cmd << " <id> <name> <dept> <cgpa>\n"; continue; }
            bool ok = cmd == "insert" ? db.insert(s) : db.update(s);
            std::cout << (ok ? "OK\n" : cmd == "insert" ? "ERROR: id already exists\n" : "ERROR: id not found\n");
        } else if (cmd == "get") {
            int id; if (!(in >> id)) { std::cout << "usage: get <id>\n"; continue; }
            const Student* s = db.get(id);
            if (s) { print({*s}); std::cout << "nodes visited: " << db.index().lastVisits() << "\n"; }
            else std::cout << "not found\n";
        } else if (cmd == "delete") {
            int id; if (!(in >> id)) { std::cout << "usage: delete <id>\n"; continue; }
            std::cout << (db.remove(id) ? "deleted\n" : "ERROR: id not found\n");
        } else if (cmd == "range") {
            int lo, hi; if (!(in >> lo >> hi)) { std::cout << "usage: range <lo> <hi>\n"; continue; }
            print(db.range(lo, hi));
        } else if (cmd == "find") {
            std::string t; in >> t; print(db.searchName(t));
        } else if (cmd == "list") print(db.all());
        else if (cmd == "tree") std::cout << db.index().toString();
        else if (cmd == "stats") {
            std::string err;
            std::cout << "order " << db.index().order() << ", height " << db.index().height()
                      << ", nodes " << db.index().nodeCount() << ", records " << db.count()
                      << ", valid " << (db.index().validate(&err) ? "yes" : "NO: " + err) << "\n";
        } else if (cmd == "order") {
            int m; if (!(in >> m) || m < 3) { std::cout << "usage: order <m>=3+>\n"; continue; }
            db.setOrder(m); std::cout << "rebuilt with order " << m << "\n";
        } else if (cmd == "gen") {
            int n; if (!(in >> n) || n < 1) { std::cout << "usage: gen <n>\n"; continue; }
            generate(db, n, rng); std::cout << "added " << n << " records\n";
        } else if (cmd == "bench") {
            int n = 100000; in >> n; bench(n);
        } else if (cmd == "save") {
            std::string f; in >> f; std::cout << (db.save(f) ? "saved\n" : "ERROR: cannot write file\n");
        } else if (cmd == "load") {
            std::string f; in >> f; int n = db.load(f);
            if (n < 0) std::cout << "ERROR: cannot open file\n"; else std::cout << "loaded " << n << " records\n";
        } else if (cmd == "clear") { db.clear(); std::cout << "cleared\n"; }
        else std::cout << "unknown command (try 'help')\n";
    }
    return 0;
}
